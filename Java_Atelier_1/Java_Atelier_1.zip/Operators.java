package Java_Atelier_1;

public class Operators {
	
		void Table(){
			System.out.println("x" + "\t" + "y" + "\t" + "x and y" + "\t" + "x or y" + "\t" + "x xor y");
		}
}
