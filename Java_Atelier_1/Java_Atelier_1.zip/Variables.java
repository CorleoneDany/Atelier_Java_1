package Java_Atelier_1;

public class Variables {
	public void Sqr_root() {
		// imprime la racine carr�e de a * a + b * b
		float a = 3.0F;
		double b = 4;
		float c;
		
		c = (float) Math.sqrt((a * a) + (b * b));
		System.out.println("c = " + c);
	}
}
